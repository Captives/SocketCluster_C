var ModelController = {};

ModelController.Services = require('../models/Services.js');
ModelController.Users = require('../models/Users.js');

module.exports = ModelController;