$(function() {

	

	observe('bind',function() {

	});

})


$(document).ready(function() {
	notify('bind');
});