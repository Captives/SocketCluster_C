var bindlock = 0;
var startlock = 0;